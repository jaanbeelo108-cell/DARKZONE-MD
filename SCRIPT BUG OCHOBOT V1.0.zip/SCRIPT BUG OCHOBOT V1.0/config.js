global.owner = ['9185686888888'] // owner number
global.connect = true // Ubah ke false jika ingin mengkoneksikan bot menggunakan QrCode
global.url = "https://t.me/alluffystore"
global.url2 = "https://t.me/alluffytestimoni"
global.packname = "𝗢𝗰𝗵𝗼𝗕𝗼𝘁 𝗖𝗿𝗮𝘀𝗵𝗲𝗿"
global.author = "AlLuffy Official"